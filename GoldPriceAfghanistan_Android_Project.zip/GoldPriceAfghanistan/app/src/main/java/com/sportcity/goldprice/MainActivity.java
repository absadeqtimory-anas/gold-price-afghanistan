package com.sportcity.goldprice;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText ounceInput, rateInput, laborInput;
    private TextView result24, result22, result21, result18, result14, status;
    private Spinner caratSpinner;
    private TextView selectedResult;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final DecimalFormat df = new DecimalFormat("#,##0.0");
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,24,39));
        getWindow().setNavigationBarColor(Color.rgb(16,24,39));
        prefs = getSharedPreferences("gold_values", MODE_PRIVATE);
        buildUi();
        calculate();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    private void addSpace(LinearLayout p, int h) {
        View v = new View(this);
        p.addView(v, new LinearLayout.LayoutParams(1,h));
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(17);
        e.setInputType(8194);
        e.setPadding(18, 10, 18, 10);
        e.setBackground(bg(Color.WHITE, 18));
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setGravity(Gravity.CENTER);
        return e;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = column();
        page.setPadding(22, 24, 22, 28);
        page.setBackgroundColor(Color.rgb(245,246,248));
        scroll.addView(page);
        setContentView(scroll);

        LinearLayout header = column();
        header.setPadding(20,22,20,22);
        header.setBackground(bg(Color.rgb(16,24,39),24));
        TextView title = text("قیمت طلای افغانستان",24,Color.WHITE,true);
        title.setGravity(Gravity.CENTER);
        header.addView(title);
        TextView sub = text("محاسبه‌گر نرخ طلا به افغانی",14,Color.rgb(220,190,105),false);
        sub.setGravity(Gravity.CENTER);
        header.addView(sub);
        page.addView(header, new LinearLayout.LayoutParams(-1,-2));
        addSpace(page,18);

        page.addView(text("نرخ‌های بازار",18,Color.rgb(25,35,50),true));
        addSpace(page,8);
        page.addView(text("قیمت هر انس طلا (دالر)",14,Color.DKGRAY,false));
        ounceInput = field("مثلاً 3771", prefs.getString("ounce","3771"));
        page.addView(ounceInput, new LinearLayout.LayoutParams(-1,55));
        addSpace(page,10);
        page.addView(text("نرخ هر دالر به افغانی",14,Color.DKGRAY,false));
        rateInput = field("مثلاً 66.300", prefs.getString("rate","66.300"));
        page.addView(rateInput, new LinearLayout.LayoutParams(-1,55));
        addSpace(page,10);
        page.addView(text("اجرت و سود اضافی (درصد، اختیاری)",14,Color.DKGRAY,false));
        laborInput = field("۰", prefs.getString("labor","0"));
        page.addView(laborInput, new LinearLayout.LayoutParams(-1,55));
        addSpace(page,12);

        Button auto = new Button(this);
        auto.setText("دریافت خودکار نرخ جهانی و دالر");
        auto.setTextSize(15);
        auto.setTextColor(Color.WHITE);
        auto.setAllCaps(false);
        auto.setBackground(bg(Color.rgb(27,112,103),18));
        page.addView(auto, new LinearLayout.LayoutParams(-1,54));
        auto.setOnClickListener(v -> fetchRates());
        status = text("برای نرخ خودکار، اینترنت لازم است.",12,Color.GRAY,false);
        status.setGravity(Gravity.CENTER);
        page.addView(status);
        addSpace(page,16);

        LinearLayout selectedCard = column();
        selectedCard.setPadding(18,18,18,18);
        selectedCard.setBackground(bg(Color.rgb(255,255,255),22));
        selectedCard.addView(text("محاسبه عیار انتخابی",16,Color.DKGRAY,true));
        caratSpinner = new Spinner(this);
        String[] carats = {"۲۴ عیار","۲۲ عیار","۲۱ عیار","۱۸ عیار","۱۴ عیار"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, carats);
        caratSpinner.setAdapter(adapter);
        selectedCard.addView(caratSpinner);
        selectedResult = text("— افغانی برای هر گرم",25,Color.rgb(150,111,20),true);
        selectedResult.setGravity(Gravity.CENTER);
        selectedCard.addView(selectedResult);
        page.addView(selectedCard, new LinearLayout.LayoutParams(-1,-2));
        addSpace(page,16);

        page.addView(text("قیمت هر گرم بر اساس عیار",18,Color.rgb(25,35,50),true));
        addSpace(page,8);
        LinearLayout prices = column();
        prices.setPadding(18,12,18,12);
        prices.setBackground(bg(Color.WHITE,20));
        result24 = priceRow(prices,"۲۴ عیار");
        result22 = priceRow(prices,"۲۲ عیار");
        result21 = priceRow(prices,"۲۱ عیار");
        result18 = priceRow(prices,"۱۸ عیار");
        result14 = priceRow(prices,"۱۴ عیار");
        page.addView(prices, new LinearLayout.LayoutParams(-1,-2));
        addSpace(page,14);

        TextView note = text("فرمول: (قیمت انس × نرخ دالر) ÷ ۳۱٫۱۰۳۵ × (عیار ÷ ۲۴). ارقام، قیمت محاسباتی طلای خام هستند؛ اجرت و سود فقط در صورت واردکردن درصد به نتیجه افزوده می‌شود.",12,Color.GRAY,false);
        page.addView(note);

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ calculate(); }
            public void afterTextChanged(Editable e){}
        };
        ounceInput.addTextChangedListener(watcher);
        rateInput.addTextChangedListener(watcher);
        laborInput.addTextChangedListener(watcher);
        caratSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id){ calculate(); }
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
    }

    private TextView priceRow(LinearLayout parent, String label) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(4,13,4,13);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView l = text(label,16,Color.DKGRAY,true);
        TextView value = text("— افغانی",16,Color.rgb(35,45,60),true);
        value.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        row.addView(l,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(value,new LinearLayout.LayoutParams(0,-2,1));
        parent.addView(row);
        View line = new View(this); line.setBackgroundColor(Color.rgb(235,237,240));
        parent.addView(line,new LinearLayout.LayoutParams(-1,1));
        return value;
    }

    private double num(EditText e, double fallback) {
        try { return Double.parseDouble(e.getText().toString().trim().replace(",","")); }
        catch(Exception ex){ return fallback; }
    }

    private void calculate() {
        if (ounceInput == null || rateInput == null) return;
        double ounce = num(ounceInput,0), rate = num(rateInput,0);
        double extra = laborInput == null ? 0 : Math.max(0,num(laborInput,0));
        double base = ounce * rate / 31.1035 * (1 + extra/100.0);
        result24.setText(df.format(base)+" افغانی");
        result22.setText(df.format(base*22/24)+" افغانی");
        result21.setText(df.format(base*21/24)+" افغانی");
        result18.setText(df.format(base*18/24)+" افغانی");
        result14.setText(df.format(base*14/24)+" افغانی");
        int[] values = {24,22,21,18,14};
        int pos = caratSpinner == null ? 0 : caratSpinner.getSelectedItemPosition();
        int k = values[Math.max(0,Math.min(pos,4))];
        selectedResult.setText(df.format(base*k/24)+" افغانی برای هر گرم");
        prefs.edit().putString("ounce",ounceInput.getText().toString())
                .putString("rate",rateInput.getText().toString())
                .putString("labor",laborInput.getText().toString()).apply();
    }

    private void fetchRates() {
        status.setText("در حال دریافت نرخ‌های تازه...");
        new Thread(() -> {
            try {
                JSONObject gold = getJson("https://api.gold-api.com/price/XAU");
                JSONObject fx = getJson("https://open.er-api.com/v6/latest/USD");
                double goldUsd = gold.getDouble("price");
                double afn = fx.getJSONObject("rates").getDouble("AFN");
                handler.post(() -> {
                    ounceInput.setText(String.format(Locale.US,"%.2f",goldUsd));
                    rateInput.setText(String.format(Locale.US,"%.4f",afn));
                    status.setText("نرخ‌ها با موفقیت دریافت شد. زمان آخرین دریافت: همین اکنون");
                    calculate();
                });
            } catch(Exception ex) {
                handler.post(() -> status.setText("دریافت خودکار ناموفق بود؛ اتصال اینترنت را بررسی کنید یا نرخ‌ها را دستی وارد کنید."));
            }
        }).start();
    }

    private JSONObject getJson(String address) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(address).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent","GoldPriceAfghanistan/1.0");
        try {
            int code = c.getResponseCode();
            if(code < 200 || code >= 300) throw new Exception("HTTP "+code);
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while((n=in.read(buf))!=-1) out.write(buf,0,n);
            in.close();
            return new JSONObject(out.toString("UTF-8"));
        } finally { c.disconnect(); }
    }
}
